import Categories from "../../Data/Categories";

const initalState = {
  availableProducts: Categories,
};

export default (state = initalState, action) => {
  return state;
};
