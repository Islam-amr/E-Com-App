class Product {
  constructor(id, title, price, img, imgs) {
    this.id = id;
    this.title = title;
    this.price = price;
    this.img = img;
    this.imgs = imgs;
  }
}

export default Product;
