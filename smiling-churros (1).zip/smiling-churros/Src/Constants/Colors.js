export default {
  primary: "rgb(70,169,87)",
  white: "#FFFFFF",
  black: "#000000",
  text: "#888888",
};
