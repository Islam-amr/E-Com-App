class CartItem {
  constructor(name, quantity, price, sum, img) {
    this.name = name;
    this.quantity = quantity;
    this.price = price;
    this.sum = sum;
    this.img = img;
  }
}

export default CartItem;
