export const ADD_TO_CART = 'ADD_TO_CART';
export const REMOVE_FROM_CART = 'REMOVE_FROM_CART';

export const addToCart = (id, name, quantity, price, img) => {
  return { type: ADD_TO_CART, payload: { id, name, quantity, price, img } };
};

export const removeFromCart = (id) => {
  return { type: REMOVE_FROM_CART, payload: id };
};
