class Category {
  constructor(id, title, products) {
    this.id = id;
    this.title = title;
    this.products = products;
  }
}

export default Category;
