// Package import
import React, { useState, useEffect } from "react";
import { View, FlatList, StyleSheet } from "react-native";
import { useSelector, useDispatch } from "react-redux";

// Data import
import Categories from "../Data/Categories";

// Theme import
import Colors from "../Constants/Colors";
import Dimensions from "../Constants/Dimensions";
import ResponsiveFont from "../Constants/ResponsiveFont";

// Components import
import Footer from "../Components/Footer";
import CategoryTab from "../Components/CategoryTab";
import ProductItem from "../Components/ProductItem";

const Products = () => {
  const categories = useSelector((state) => state.Products.availableProducts);
  console.log(useSelector((state) => state.Cart));
  const [activeTabId, setActiveTabId] = useState(categories[0].id);
  const handleCategoryPress = (id) => {
    setActiveTabId(id);
  };

  return (
    <View style={styles.mainView}>
      <View style={styles.searchCon}></View>
      <View style={styles.tabsCon}>
        <FlatList
          data={categories}
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item, index }) => {
            return (
              <CategoryTab
                item={item}
                activeTabId={activeTabId}
                onTouch={handleCategoryPress}
              />
            );
          }}
        />
      </View>
      <View style={styles.productsCon}>
        <FlatList
          showsVerticalScrollIndicator={false}
          numColumns={2}
          alwaysBounceVertical
          data={Categories.find((item) => item.id === activeTabId).products}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => {
            return <ProductItem item={item} />;
          }}
        />
      </View>
      <Footer />
    </View>
  );
};

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  searchCon: {
    width: Dimensions.width * 0.9,
    height: Dimensions.height * 0.06,
    marginVertical: Dimensions.height * 0.01,
    borderRadius: 1000,
    borderWidth: 1,
    borderColor: "black",
    alignSelf: "center",
  },
  tabsCon: {
    width: Dimensions.width,
    alignSelf: "center",
  },
  productsCon: {
    height: Dimensions.height * 0.75,
    paddingBottom: Dimensions.height * 0.1,
    paddingHorizontal: Dimensions.width * 0.025,
  },
});
export default Products;
